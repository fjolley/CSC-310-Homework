package hw6;

import java.util.*;

//Class for #1
class priority{
    List<Integer> p = new LinkedList<Integer>();
    
    //Inserts a new value in the list
    void insert(int x){
        p.add(x);
    }
    
    //Returns the minimum remaining value
    int getMinNum(){
        int m = p.get(0);
        for (int i = 1; i < p.size(); i++)
            if(m>p.get(i))
                m=p.get(i);
        return m;
    }
    
    //Returns the index of the minimum remaining value
    int getMinInd(){
        int m = p.get(0);
        int j=0;
        for (int i = 1; i < p.size(); i++)
            if(m>p.get(i)){
                m=p.get(i);
                j=i;
            }
        return j;
    }
    
    //Retrieves a value
    int get(int x){
        return p.get(x);
    }
    
    //Removes the minimum value
    void removeMin(){
        p.remove(getMinInd());
    }
    
    //Sorting method
    void inSort(){
        List<Integer> p2 = new LinkedList<Integer>();
        int n = p.size();
        for (int i = 0; i < n; i++){ //Loops through
            for (int j = 0; j < p.size(); j++){//finding each minimum value..
                p2.add(getMinNum()); //and adding it to the second list
                removeMin(); //then removes it from the first list
            }
        }
        for (int i = 0; i < n; i++)
            p.add(p2.get(i)); //moves it all back to the original list
    }
    
    //Returns the length of the list
    int length(){
        return p.size();
    }
}

//Class for #2
class heap{
    List<Integer> h = new ArrayList<Integer>();
    
    //Switches values for heaps
    void switcher(int x, int y){
        int temp = h.get(y);
        h.set(x, h.get(y));
        h.set(y, temp);
    }
    
    //Identifies parent 
    int parent(int x){
        return (x-1)/2;
    }
    
    //Identifies left child
    int left(int x){
        return 2*x+1;
    }
    
    //Identifies right child
    int right(int x){
        return 2*x+2;
    }
    
    //True if a parent has a left child 
    boolean hasLeft(int x){
        return 2*x+1 < h.size()-1;
    }
    
    //True if parent has a right child
    boolean hasRight(int x){
        return 2*x+2 < h.size()-1;
    }
    
    //Put in a new value
    void insert(int x){
        h.add(x);
        upheap(h.size()-1);
    }
    
    //Return minimum value
    int find_min(){
        return h.get(0);
    }
    
    //Remove minimum value
    int remove_min(){
        int ret = h.get(0);
        switcher(0, h.size()-1);
        h.remove(h.size()-1);
        downheap(0);
        return ret;
    }
    
    //True if list is empty
    boolean is_empty(){
        if(h.size() == 0)
            return true;
        else
            return false;
    }
    
    //Returns list size
    int size(){
        return h.size();
    }
    
    //Moves in upheap
    void upheap(int pos){
        if(pos != 0){
            if(h.get(pos) < h.get(parent(pos))){
                switcher(pos, parent(pos));
                upheap(parent(pos));
            }
        }
    }
    
    //Moves in downheap
    void downheap(int pos){
        if(pos < h.size()){
            if(h.get(pos) > h.get(left(pos))){
                switcher(pos, left(pos));
                if(hasLeft(pos))
                    downheap(left(pos));
            }
            else if(h.get(pos) > h.get(right(pos))){
                switcher(pos, right(pos));
                if(hasRight(pos))
                    downheap(right(pos));
            }
        }
    }
    
    void build_heap(ArrayList l){
        h.clear();
        for (int i = 0; i < l.size(); i++) {
            h.add((Integer) l.get(i));
            upheap(h.size()-1);
        }
    }
}

class binaryHeap{
    private List<Integer> bh = new ArrayList<>();
    
    void BinHeap(ArrayList b){
        bh.clear();
        for (int i = 0; i < b.size(); i++) {
            bh.add((Integer) b.get(i));
            up(bh.size()-1);
        }
    }
    
    void swap(int a, int b){
        Integer t = bh.get(b);
        bh.set(b, bh.get(a));
        bh.set(a, t);
    }
    
    int parent(int x){
        return (x-1)/2;
    }
    
    int left(int x){
        return 2*x+1;
    }
    
    int right(int x){
        return 2*x+2;
    }
    
    boolean hasLeft(int x){
        return 2*x+1 < bh.size() && bh.get(2*x+1) != null;
    }
    
    boolean hasRight(int x){
        return 2*x+2 < bh.size() && bh.get(2*x+2) != null;
    }
    
    void insert(int x){
        bh.add(x);
        up(bh.size()-1);
    }
    
    int find_min(){
        return bh.get(0);
    }
    
    int remove_min(){
        int ret = bh.get(0);
        swap(0, bh.size()-1);
        bh.remove(bh.size()-1);
        down(0);
        return ret;
    }
    
    boolean is_empty(){
        if(bh.size() == 0)
            return true;
        else
            return false;
    }
    
    int size(){
        return bh.size();
    }
    
    void up(int pos){
        if(pos != 0){
            if(bh.get(pos) < bh.get(parent(pos))){
                swap(pos, parent(pos));
                up(parent(pos));
            }
        }
    }
    
    void down(int pos){
        Integer childOne = null;
        Integer childTwo = null;
        if(hasLeft(pos))
            childOne = left(pos);
        if(hasRight(pos))
            childTwo = right(pos);
        int smallest = -1;
        if(childOne != null && childTwo!= null )
            smallest = bh.get(childOne) < bh.get(childTwo) ? childOne : childTwo;
        else if(childOne!= null )
            smallest = childOne;
        else if(childTwo!= null )
            smallest = childTwo;
        else
            return;
        if(bh.get(smallest) < bh.get(pos)){
            swap(pos, smallest);
            down(smallest);
        }
    }
}

public class Hw6 {
    
    static void heapIt(int[] h, int size, int i){
        int largest = i;
        int l = 2*i+1;
        int r = 2*i+2;
        
        if(l<size && h[l] > h[largest])
            largest = l;
        if(r<size && h[r] > h[largest])
            largest = r;
        if(largest != i){
            int swap = h[i];
            h[i] = h[largest];
            h[largest] = swap;
            
            heapIt(h, size, largest);
        }
    }
    
    static void heapSort(int[] h){
        int n = h.length;
        
        for (int i = (n/2); i >= 0; i--)
            heapIt(h, n, i);
        
        for (int i = n-1; i >= 0; i--) {
            int t = h[0];
            h[0] = h[i];
            h[i] = t;
            heapIt(h, i, 0);
        }
        for (int i = 0; i < h.length; i++)
            System.out.print(h[i] + " ");
        System.out.println();
    }
    
    public static void main(String[] args) {
        System.out.println("#1, Priority Queue Sort: ");
        priority p = new priority();
        int[] a = {1,6,3,7,5,9};
        for (int i = 0; i < a.length; i++)
            p.insert(a[i]);
        p.inSort();
        for (int i = 0; i < p.length(); i++)
            System.out.print(p.get(i)+" ");
        
        System.out.println(); System.out.println();
        System.out.println("#2");
        int[] h = {1,7,5,2,6,4};
        heapSort(h);
        
        System.out.println();
        System.out.println("#3");
        binaryHeap min = new binaryHeap();
        
        min.insert(5);
        min.insert(7);
        min.insert(3);
        min.insert(11);
        
        System.out.print(min.remove_min()+" ");
        System.out.print(min.remove_min()+" ");
        System.out.print(min.remove_min()+" ");
        System.out.print(min.remove_min()+" ");
    }
}
