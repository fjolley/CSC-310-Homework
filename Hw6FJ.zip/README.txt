None of these parts require user input to be run and tested. 

#1: To change the input for this question, alter the integers in array a.

#2: Similarly to #1, change the integers in array h to alter the output.

#3: For this one, change the integers in the parentheses for the min.insert() functions.