#Faith Jolley
#CSC 310
#CRN 21103

class Backward:
   str=" "
   i=1
   while i<6:
       s = input("Enter a string: ")
       str=s+"\n"+str
       print(str)

class OddPair:
   nums = []
   areOdd=False
   oddCount = 0
   #An odd number can only result from two odd numbers multiplied together.
   #oddCount needs to be more than 1 to have at least one a pair be odd
   x=1
   while x>0:
       x = (int)(input("Enter an integer (0 to stop): "))
       nums.append(x)
       if x%2!=0:
           oddCount+=1
   print(nums)
   if oddCount > 1:
       areOdd = True
   print(areOdd)


class Permute:
    from itertools import permutations
    uList = []
    s = "y"

    while s != "n" and s != "N":
        x = (int)(input("Enter an integer: "))
        uList.append(x)
        s = input("Enter another? (Y/N): ")

    perm = permutations(uList)

    for i in list(perm):
        print(i)


class Hamming:
    #Gathering input & input validation
    x = (int)(input("Enter a value for x: "))
    while x < 0 or x > 2147483648:
        print("Value must be greater than 0 and less than 2147483648.")
        x = (int)(input("Re-enter value for x: "))
    xTemp = x
    y = (int)(input("Enter a value for y: "))
    while y < 0 or y > 2147483648:
        print("Value must be greater than 0 and less than 2147483648.")
        y = (int)(input("Re-enter value for y: "))
    yTemp = y

    #Convert decimal to binary
    xBin = []
    while xTemp > 0:
        if xTemp%2 == 1:
            xBin.append(1)
        else:
            xBin.append(0)
        xTemp = (int)(xTemp/2)
    yBin = []
    while yTemp > 0:
        if yTemp % 2 == 1:
            yBin.append(1)
        else:
            yBin.append(0)
        yTemp = (int)(yTemp / 2)
    #Binary read in backwards to help find differences

    #The amount of differences in binary digits per index is equivalent to
    #the Hamming distance.

    diffCount = 0
    0s = 0
    if len(xBin) > len(yBin):
        for i in range(len(yBin)):
            if xBin[i] != yBin[i]:
                diffCount +=1
            if xBin[i] = 0:
                z0s -=1
        for i in range(len(xBin)):
            if xBin[i] = 0:
                z0s +=1
        diffCount += len(xBin)-len(yBin) -z0s
        for i in range(len(xBin)):
    else:
        for i in range(len(xBin)):
            if xBin[i] != yBin[i]:
                diffCount += 1
            if yBin[i] = 0:
                z0s -=1
        for i in range(len(yBin)):
            if yBin[i] = 0:
                z0s +=1
        diffCount += len(yBin) - len(xBin) - z0s

    print(diffCount)
