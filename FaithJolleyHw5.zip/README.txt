To run the Tower of Hanoi section, enter the desired number of discs when prompted.
The steps will be displayed in the output section.

To run the Traversal section, alter the code in the main method of class Hw5 for the
variable t, using the value 0 as a null value.