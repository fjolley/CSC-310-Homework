package hw5;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class stack {
    List<Integer> s = new ArrayList<Integer>();
    
    void push(int n){
        s.add(n);
    }
    
    int top(){
        if (s.isEmpty())
            System.out.println("Array is empty.");
        return s.get(s.size()-1);
    }
    
    int pop(){
        if (s.isEmpty())
            System.out.println("Array is empty.");
        int n = s.get(s.size()-1);
        s.remove(s.size()-1);
        return n;
    }
}

public class Hw5 {
    static void hanoi(int n, stack from, stack to, stack spare, char fr, char t, char sp){
        //(above) num of discs, stack A, stack C, stack B, stack A identifier, B ID, C ID
        if (n == 1)
        { 
            System.out.println("Move disk 1 to peg " + t);
            to.push(from.pop());
            return; //Blank return to avoid infinite loop
        }
        
        hanoi(n-1, from, spare, to, fr, sp, t); 
        System.out.println("Move disk " + from.top() + " to peg " + t);
        to.push(from.pop());
        hanoi(n-1, spare, to, from, sp, t, fr);
    }
    
    static void inOrder(int[] t, int i){
        //(above) arrray for tree, index of position
        if(t[i] != 0){ //To skip null values
            if(i<t.length){ //Index should not exceed length
                if((i*2 + 1) < t.length){ //Has children
                    inOrder(t, (i*2 + 1)); }
                if(t[i] != 0) //Not null
                    System.out.print(t[i] + " "); //Print value there
                if((i*2+2) < t.length){ //Position
                    inOrder(t, (i*2 + 2)); }
            }
        }
    }
    
    static void preOrder(int[] t, int i){
        //(above) arrray for tree, index of position
        if(t[i] != 0){ //To skip null values
            if(i < t.length){ //Index should not exceed length
                System.out.print(t[i] + " "); //Print value
                if((i*2 + 1) < t.length){ //Has children
                    preOrder(t, (i*2 + 1)); }
                if((i*2+2) < t.length){ //Position
                    preOrder(t, (i*2 + 2)); }
            }
        }
    }
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("#1: Tower of Hanoi ");
        stack a = new stack();
        stack b = new stack();
        stack c = new stack();
        
        System.out.print("Enter the amount of discs: ");
        int n = in.nextInt();
        
        for (int i = n; i > 0; i--) //Loop to add discs to the first stack
            a.push(i);
        
        hanoi(n, a, c, b, 'A', 'C', 'B');
        System.out.println();
        
        System.out.println("#2: Traversal");
        int[] t = {1, 0, 2, 0, 0, 3};
        
        System.out.print("Inorder:  "); //Left -> Root -> Right
        inOrder(t,0); 
        System.out.println();
        
        System.out.print("Preorder: "); //Root -> Left -> Right
        preOrder(t, 0);
    }
}